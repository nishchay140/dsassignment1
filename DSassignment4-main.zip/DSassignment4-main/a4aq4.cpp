#include <iostream>
using namespace std;

class Queue {
    int *arr;
    int front, rear, capacity;
public:
    Queue(int size) {
        arr = new int[size];
        front = 0;
        rear = -1;
        capacity = size;
    }
    ~Queue() {
        delete[] arr;
    }
    void enqueue(int x) {
        if (rear == capacity - 1) return;
        arr[++rear] = x;
    }
    int dequeue() {
        if (front > rear) return -1;
        return arr[front++];
    }
    int peek() {
        if (front > rear) return -1;
        return arr[front];
    }
    bool isEmpty() {
        return front > rear;
    }
    int size() {
        return rear - front + 1;
    }
    void enqueueFront(int x) {
        if (front > 0) {
            arr[--front] = x;
        }
    }
};

int countStudentsUnableToEat(int students[], int sandwiches[], int n) {
    Queue q(n);
    for (int i = 0; i < n; i++) q.enqueue(students[i]);

    int top = 0; // index for sandwiches stack (top is sandwiches[top])

    int noProgressCount = 0; // counts how many students have been moved without eating

    while (!q.isEmpty() && top < n) {
        int studentPref = q.dequeue();

        if (studentPref == sandwiches[top]) {
            // Student eats sandwich
            top++;
            noProgressCount = 0; // reset as progress is made
        } else {
            // Student goes to back of queue
            q.enqueue(studentPref);
            noProgressCount++;
        }

        // If all students in queue have been cycled without eating the current sandwich, break
        if (noProgressCount == q.size()) {
            break;
        }
    }

    return q.size(); // number of students unable to eat
}

int main() {
    int students[] = {1, 1, 0, 0};
    int sandwiches[] = {0, 1, 0, 1};
    int n = 4;

    cout << countStudentsUnableToEat(students, sandwiches, n) << "\n"; // Output: 0

    return 0;
}
