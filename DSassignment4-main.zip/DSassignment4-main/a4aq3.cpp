#include <iostream>
using namespace std;

class Queue {
    int *arr;
    int front, rear, capacity;
public:
    Queue(int size) {
        arr = new int[size];
        front = 0;
        rear = -1;
        capacity = size;
    }
    ~Queue() {
        delete[] arr;
    }
    void enqueue(int x) {
        if (rear == capacity - 1) return;
        arr[++rear] = x;
    }
    int dequeue() {
        if (front > rear) return -1;
        return arr[front++];
    }
    int peek() {
        if (front > rear) return -1;
        return arr[front];
    }
    bool isEmpty() {
        return front > rear;
    }
};

class Stack {
    int *arr;
    int top;
    int capacity;
public:
    Stack(int size) {
        arr = new int[size];
        top = -1;
        capacity = size;
    }
    ~Stack() {
        delete[] arr;
    }
    void push(int x) {
        if (top == capacity - 1) return;
        arr[++top] = x;
    }
    int pop() {
        if (top == -1) return -1;
        return arr[top--];
    }
    int peek() {
        if (top == -1) return -1;
        return arr[top];
    }
    bool isEmpty() {
        return top == -1;
    }
};

bool canArrangeQueue(Queue &input, int n) {
    Stack s(n);
    int expected = 1;

    while (!input.isEmpty() || !s.isEmpty()) {
        if (!input.isEmpty() && input.peek() == expected) {
            input.dequeue();
            expected++;
        }
        else if (!s.isEmpty() && s.peek() == expected) {
            s.pop();
            expected++;
        }
        else if (!input.isEmpty()) {
            s.push(input.dequeue());
        }
        else {
            // No move possible
            break;
        }
    }
    return expected == n + 1;
}

int main() {
    int n = 5;
    int arr[] = {5, 1, 2, 3, 4};
    Queue input(n);
    for (int i = 0; i < n; i++) {
        input.enqueue(arr[i]);
    }

    bool result = canArrangeQueue(input, n);
    cout << (result ? "Yes" : "No") << "\n";

    return 0;
}
