#include <iostream>
using namespace std;

class Queue {
    int *arr;
    int front, rear, capacity;
public:
    Queue(int size) {
        arr = new int[size];
        front = 0;
        rear = -1;
        capacity = size;
    }
    ~Queue() {
        delete[] arr;
    }
    void enqueue(int x) {
        if (rear == capacity - 1) return;
        arr[++rear] = x;
    }
    int dequeue() {
        if (front > rear) return -1;
        return arr[front++];
    }
    bool isEmpty() {
        return front > rear;
    }
    int size() {
        return rear - front + 1;
    }
    // Reset queue to reuse if needed
    void reset() {
        front = 0; rear = -1;
    }
    // For printing
    void print() {
        for (int i = front; i <= rear; i++) {
            cout << arr[i];
            if (i < rear) cout << ", ";
        }
        cout << "\n";
    }
};

void sortQueue(Queue &q) {
    int n = q.size();
    for (int i = 0; i < n; i++) {
        // Find minimum in remaining queue elements
        int min_val = INT_MAX;
        int size = q.size();
        for (int j = 0; j < size; j++) {
            int curr = q.dequeue();
            if (curr < min_val) min_val = curr;
            q.enqueue(curr);
        }

        // Now remove the first occurrence of min_val and enqueue all others back
        bool min_found = false;
        size = q.size();
        for (int j = 0; j < size; j++) {
            int curr = q.dequeue();
            if (curr == min_val && !min_found) {
                min_found = true; // remove this one (don't enqueue now)
            } else {
                q.enqueue(curr);
            }
        }

        // enqueue min_val at the rear (sorted part)
        q.enqueue(min_val);
    }
}

int main() {
    Queue q(100);

    // Input: 11, 5, 4, 21
    q.enqueue(11);
    q.enqueue(5);
    q.enqueue(4);
    q.enqueue(21);

    sortQueue(q);

    q.print(); // Output: 4, 5, 11, 21

    return 0;
}
