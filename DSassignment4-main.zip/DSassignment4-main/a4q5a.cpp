#include <iostream>
using namespace std;

class Queue {
    int *arr;
    int front, rear, capacity;
public:
    Queue(int size) {
        arr = new int[size];
        front = 0;
        rear = -1;
        capacity = size;
    }
    ~Queue() {
        delete[] arr;
    }
    void enqueue(int x) {
        if (rear == capacity - 1) return;
        arr[++rear] = x;
    }
    int dequeue() {
        if (front > rear) return -1;
        return arr[front++];
    }
    int size() {
        return rear - front + 1;
    }
    bool empty() {
        return front > rear;
    }
    void reset() {
        front = 0;
        rear = -1;
    }
};

class StackUsingTwoQueues {
    Queue q1, q2;
public:
    StackUsingTwoQueues(int size): q1(size), q2(size) {}

    void push(int x) {
        q1.enqueue(x);
    }

    int pop() {
        if (q1.empty()) return -1;
        while (q1.size() > 1) {
            q2.enqueue(q1.dequeue());
        }
        int val = q1.dequeue();
        swap(q1, q2);
        return val;
    }

    bool empty() {
        return q1.empty();
    }
};

int main() {
    StackUsingTwoQueues s(100);

    s.push(10);
    s.push(20);
    s.push(30);

    cout << s.pop() << "\n"; // 30
    cout << s.pop() << "\n"; // 20
    s.push(40);
    cout << s.pop() << "\n"; // 40
    cout << s.pop() << "\n"; // 10
    cout << s.pop() << "\n"; // -1 (empty)

    return 0;
}
