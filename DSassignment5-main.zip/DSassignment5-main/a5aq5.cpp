#include <iostream>
using namespace std;

struct Node {
    int coeff;
    int power;
    Node* next;
};

class Polynomial {
    Node* head;
public:
    Polynomial() {
        head = nullptr;
    }

    void insertTerm(int c, int p) {
        Node* newNode = new Node{c, p, nullptr};
        if (!head || head->power < p) {
            newNode->next = head;
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next && temp->next->power > p)
            temp = temp->next;
        if (temp->power == p) {
            temp->coeff += c;  // Add coefficients if power already exists
            delete newNode;
        } else if (temp->next && temp->next->power == p) {
            temp->next->coeff += c;
            delete newNode;
        } else {
            newNode->next = temp->next;
            temp->next = newNode;
        }
    }

    static Polynomial add(Polynomial &p1, Polynomial &p2) {
        Polynomial result;
        Node* t1 = p1.head;
        Node* t2 = p2.head;

        while (t1 && t2) {
            if (t1->power == t2->power) {
                int sumCoeff = t1->coeff + t2->coeff;
                if (sumCoeff != 0)
                    result.insertTerm(sumCoeff, t1->power);
                t1 = t1->next;
                t2 = t2->next;
            } else if (t1->power > t2->power) {
                result.insertTerm(t1->coeff, t1->power);
                t1 = t1->next;
            } else {
                result.insertTerm(t2->coeff, t2->power);
                t2 = t2->next;
            }
        }

        // Add remaining terms
        while (t1) {
            result.insertTerm(t1->coeff, t1->power);
            t1 = t1->next;
        }
        while (t2) {
            result.insertTerm(t2->coeff, t2->power);
            t2 = t2->next;
        }

        return result;
    }

    void display() {
        Node* temp = head;
        while (temp) {
            cout << temp->coeff << "x^" << temp->power;
            if (temp->next)
                cout << " + ";
            temp = temp->next;
        }
        cout << "\n";
    }
};

int main() {
    Polynomial p1, p2;

    // Polynomial 1: 5x^2 + 4x^1 + 2
    p1.insertTerm(5, 2);
    p1.insertTerm(4, 1);
    p1.insertTerm(2, 0);

    // Polynomial 2: 5x^1 + 5
    p2.insertTerm(5, 1);
    p2.insertTerm(5, 0);

    cout << "Polynomial 1: ";
    p1.display();

    cout << "Polynomial 2: ";
    p2.display();

    Polynomial sum = Polynomial::add(p1, p2);

    cout << "Sum: ";
    sum.display();

    return 0;
}
