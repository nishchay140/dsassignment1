#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

class SinglyLinkedList {
    Node* head;
public:
    SinglyLinkedList() {
        head = nullptr;
    }

    void insertAtEnd(int val) {
        Node* newNode = new Node{val, nullptr};
        if (!head) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next)
            temp = temp->next;
        temp->next = newNode;
    }

    Node* rotateLeft(Node* head, int k) {
        if (!head || !head->next || k == 0)
            return head;

        // Find length and last node
        Node* temp = head;
        int length = 1;
        while (temp->next) {
            temp = temp->next;
            length++;
        }

        k = k % length; // In case k > length
        if (k == 0)
            return head;

        // temp is at last node now, link it to head to make it circular
        temp->next = head;

        // Find new tail: (length - k)th node
        int stepsToNewTail = k;
        Node* newTail = head;
        for (int i = 1; i < stepsToNewTail; i++) {
            newTail = newTail->next;
        }

        // newHead is next of newTail
        Node* newHead = newTail->next;

        // Break the circle
        newTail->next = nullptr;

        return newHead;
    }

    void rotateLeftByK(int k) {
        head = rotateLeft(head, k);
    }

    void display() {
        Node* temp = head;
        while (temp) {
            cout << temp->data;
            if (temp->next)
                cout << "->";
            temp = temp->next;
        }
        cout << "\n";
    }
};

int main() {
    SinglyLinkedList list;
    int arr[] = {1, 2, 3, 4, 5};
    int n = sizeof(arr) / sizeof(arr[0]);
    for (int i = 0; i < n; i++)
        list.insertAtEnd(arr[i]);

    int k = 2;
    list.rotateLeftByK(k);

    list.display();  // Output: 3->4->5->1->2

    return 0;
}
