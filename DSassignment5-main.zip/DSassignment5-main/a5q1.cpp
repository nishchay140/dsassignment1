#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

class SinglyLinkedList {
    Node* head;
public:
    SinglyLinkedList() {
        head = nullptr;
    }

    void insertAtBeginning(int val) {
        Node* newNode = new Node{val, head};
        head = newNode;
    }

    void insertAtEnd(int val) {
        Node* newNode = new Node{val, nullptr};
        if (!head) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next)
            temp = temp->next;
        temp->next = newNode;
    }

    void insertBefore(int key, int val) {
        if (!head) return;
        if (head->data == key) {
            insertAtBeginning(val);
            return;
        }
        Node* temp = head;
        while (temp->next && temp->next->data != key)
            temp = temp->next;
        if (temp->next) {
            Node* newNode = new Node{val, temp->next};
            temp->next = newNode;
        }
    }

    void insertAfter(int key, int val) {
        Node* temp = head;
        while (temp && temp->data != key)
            temp = temp->next;
        if (temp) {
            Node* newNode = new Node{val, temp->next};
            temp->next = newNode;
        }
    }

    void deleteFromBeginning() {
        if (!head) return;
        Node* temp = head;
        head = head->next;
        delete temp;
    }

    void deleteFromEnd() {
        if (!head) return;
        if (!head->next) {
            delete head;
            head = nullptr;
            return;
        }
        Node* temp = head;
        while (temp->next && temp->next->next)
            temp = temp->next;
        delete temp->next;
        temp->next = nullptr;
    }

    void deleteNode(int val) {
        if (!head) return;
        if (head->data == val) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        Node* temp = head;
        while (temp->next && temp->next->data != val)
            temp = temp->next;
        if (temp->next) {
            Node* toDelete = temp->next;
            temp->next = toDelete->next;
            delete toDelete;
        }
    }

    int search(int val) {
        Node* temp = head;
        int pos = 1;
        while (temp) {
            if (temp->data == val)
                return pos;
            temp = temp->next;
            pos++;
        }
        return -1;
    }

    void display() {
        Node* temp = head;
        while (temp) {
            cout << temp->data;
            if (temp->next)
                cout << " -> ";
            temp = temp->next;
        }
        cout << "\n";
    }
};

int main() {
    SinglyLinkedList list;
    int choice, val, key, pos;
    while (true) {
        cout << "1. Insert at beginning\n2. Insert at end\n3. Insert before a node\n4. Insert after a node\n5. Delete from beginning\n6. Delete from end\n7. Delete a specific node\n8. Search node\n9. Display list\n10. Exit\n";
        cin >> choice;
        switch (choice) {
            case 1:
                cin >> val;
                list.insertAtBeginning(val);
                break;
            case 2:
                cin >> val;
                list.insertAtEnd(val);
                break;
            case 3:
                cin >> key >> val;
                list.insertBefore(key, val);
                break;
            case 4:
                cin >> key >> val;
                list.insertAfter(key, val);
                break;
            case 5:
                list.deleteFromBeginning();
                break;
            case 6:
                list.deleteFromEnd();
                break;
            case 7:
                cin >> val;
                list.deleteNode(val);
                break;
            case 8:
                cin >> val;
                pos = list.search(val);
                if (pos == -1)
                    cout << "Not found\n";
                else
                    cout << "Position: " << pos << "\n";
                break;
            case 9:
                list.display();
                break;
            case 10:
                return 0;
            default:
                cout << "Invalid choice\n";
        }
    }
}
