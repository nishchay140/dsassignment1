#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

class SinglyLinkedList {
    Node* head;
public:
    SinglyLinkedList() {
        head = nullptr;
    }

    void insertAtEnd(int val) {
        Node* newNode = new Node{val, nullptr};
        if (!head) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next)
            temp = temp->next;
        temp->next = newNode;
    }

    Node* reverseKGroup(Node* head, int k) {
        if (!head) return nullptr;
        Node* curr = head;
        Node* prev = nullptr;
        Node* next = nullptr;

        // Check if there are at least k nodes left
        Node* check = head;
        int count = 0;
        while (check && count < k) {
            check = check->next;
            count++;
        }
        if (count < k) return head; // less than k nodes, return head as is

        count = 0;
        while (curr && count < k) {
            next = curr->next;
            curr->next = prev;
            prev = curr;
            curr = next;
            count++;
        }

        if (next)
            head->next = reverseKGroup(next, k);

        return prev;
    }

    void reverseInGroups(int k) {
        head = reverseKGroup(head, k);
    }

    void display() {
        Node* temp = head;
        while (temp) {
            cout << temp->data;
            if (temp->next) cout << "->";
            temp = temp->next;
        }
        cout << "\n";
    }
};

int main() {
    SinglyLinkedList list;
    int arr[] = {1, 2, 3, 4, 5, 6, 7};
    int n = sizeof(arr) / sizeof(arr[0]);
    for (int i = 0; i < n; i++)
        list.insertAtEnd(arr[i]);

    int k = 3;
    list.reverseInGroups(k);
    list.display();  // Output: 3->2->1->6->5->4->7

    return 0;
}
