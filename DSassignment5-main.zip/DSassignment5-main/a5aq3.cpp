#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

class SinglyLinkedList {
    Node* head;
public:
    SinglyLinkedList() {
        head = nullptr;
    }

    void insertAtEnd(int val) {
        Node* newNode = new Node{val, nullptr};
        if (!head) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next)
            temp = temp->next;
        temp->next = newNode;
    }

    // Function to create a loop for testing purpose
    void createLoop(int pos) {
        if (pos == 0) return;
        Node* temp = head;
        Node* loopNode = nullptr;
        int count = 1;
        while (temp->next) {
            if (count == pos)
                loopNode = temp;
            temp = temp->next;
            count++;
        }
        temp->next = loopNode;
    }

    bool detectAndRemoveLoop() {
        if (!head || !head->next) return false;
        Node* slow = head;
        Node* fast = head;

        while (fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
            if (slow == fast) {
                removeLoop(slow);
                return true;
            }
        }
        return false;
    }

    void removeLoop(Node* loopNode) {
        Node* ptr1 = head;
        Node* ptr2 = loopNode;

        // If loopNode is at head (loop includes entire list)
        if (ptr1 == ptr2) {
            while (ptr2->next != ptr1)
                ptr2 = ptr2->next;
            ptr2->next = nullptr;
            return;
        }

        // Move both pointers at same pace to find loop start
        while (ptr1->next != ptr2->next) {
            ptr1 = ptr1->next;
            ptr2 = ptr2->next;
        }
        ptr2->next = nullptr; // Break the loop
    }

    void display() {
        Node* temp = head;
        while (temp) {
            cout << temp->data;
            if (temp->next) cout << "->";
            temp = temp->next;
        }
        cout << "\n";
    }
};

int main() {
    SinglyLinkedList list;
    int arr[] = {1, 2, 3, 4, 5};
    for (int val : arr)
        list.insertAtEnd(val);

    // Create loop for testing (last node points to node at position 2)
    list.createLoop(2);

    if (list.detectAndRemoveLoop()) {
        cout << "Loop detected and removed.\n";
    } else {
        cout << "No loop detected.\n";
    }

    list.display();  // Output should be: 1->2->3->4->5

    return 0;
}
