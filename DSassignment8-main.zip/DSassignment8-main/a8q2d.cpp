#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* left;
    Node* right;
};

Node* createNode(int data)
{
    Node* newNode=new Node;
    newNode->data=data;
    newNode->left=NULL;
    newNode->right=NULL;
    return newNode;
}

Node* insert(Node* root,int data)
{
    if(root==NULL)
        return createNode(data);
    if(data<root->data)
        root->left=insert(root->left,data);
    else if(data>root->data)
        root->right=insert(root->right,data);
    return root;
}

Node* findMin(Node* node)
{
    while(node&&node->left!=NULL)
        node=node->left;
    return node;
}

Node* inorderSuccessor(Node* root,Node* x)
{
    if(x->right!=NULL)
        return findMin(x->right);
    Node* succ=NULL;
    while(root!=NULL)
    {
        if(x->data<root->data)
        {
            succ=root;
            root=root->left;
        }
        else if(x->data>root->data)
            root=root->right;
        else
            break;
    }
    return succ;
}

int main()
{
    Node* root=NULL;
    root=insert(root,20);
    insert(root,8);
    insert(root,22);
    insert(root,4);
    insert(root,12);
    insert(root,10);
    insert(root,14);
    Node* temp=root->left->right;
    Node* succ=inorderSuccessor(root,temp);
    cout<<"Inorder Successor: "<<succ->data;
    return 0;
}
