#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* left;
    Node* right;
};

Node* createNode(int data)
{
    Node* newNode=new Node;
    newNode->data=data;
    newNode->left=NULL;
    newNode->right=NULL;
    return newNode;
}

Node* insert(Node* root,int data)
{
    if(root==NULL)
        return createNode(data);
    if(data<root->data)
        root->left=insert(root->left,data);
    else if(data>root->data)
        root->right=insert(root->right,data);
    return root;
}

Node* findMax(Node* root)
{
    if(root==NULL)
        return NULL;
    while(root->right!=NULL)
        root=root->right;
    return root;
}

int main()
{
    Node* root=NULL;
    root=insert(root,10);
    insert(root,5);
    insert(root,15);
    insert(root,2);
    Node* max=findMax(root);
    cout<<"Maximum: "<<max->data;
    return 0;
}
