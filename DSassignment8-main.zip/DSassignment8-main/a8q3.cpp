#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* left;
    Node* right;
};

Node* createNode(int data)
{
    Node* newNode=new Node;
    newNode->data=data;
    newNode->left=NULL;
    newNode->right=NULL;
    return newNode;
}

Node* insert(Node* root,int data)
{
    if(root==NULL)
        return createNode(data);
    if(data<root->data)
        root->left=insert(root->left,data);
    else if(data>root->data)
        root->right=insert(root->right,data);
    return root;
}

Node* findMin(Node* root)
{
    while(root->left!=NULL)
        root=root->left;
    return root;
}

Node* deleteNode(Node* root,int key)
{
    if(root==NULL)
        return root;
    if(key<root->data)
        root->left=deleteNode(root->left,key);
    else if(key>root->data)
        root->right=deleteNode(root->right,key);
    else
    {
        if(root->left==NULL)
        {
            Node* temp=root->right;
            delete root;
            return temp;
        }
        else if(root->right==NULL)
        {
            Node* temp=root->left;
            delete root;
            return temp;
        }
        Node* temp=findMin(root->right);
        root->data=temp->data;
        root->right=deleteNode(root->right,temp->data);
    }
    return root;
}

int maxDepth(Node* root)
{
    if(root==NULL)
        return 0;
    int l=maxDepth(root->left);
    int r=maxDepth(root->right);
    return (l>r?l:r)+1;
}

int minDepth(Node* root)
{
    if(root==NULL)
        return 0;
    int l=minDepth(root->left);
    int r=minDepth(root->right);
    return (l<r?l:r)+1;
}

int main()
{
    Node* root=NULL;
    root=insert(root,10);
    insert(root,5);
    insert(root,15);
    insert(root,3);
    insert(root,7);
    root=deleteNode(root,5);
    cout<<"Max Depth: "<<maxDepth(root)<<"\n";
    cout<<"Min Depth: "<<minDepth(root);
    return 0;
}
