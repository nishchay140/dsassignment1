#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* left;
    Node* right;
};

Node* createNode(int data)
{
    Node* newNode=new Node;
    newNode->data=data;
    newNode->left=NULL;
    newNode->right=NULL;
    return newNode;
}

Node* insert(Node* root,int data)
{
    if(root==NULL)
        return createNode(data);
    if(data<root->data)
        root->left=insert(root->left,data);
    else if(data>root->data)
        root->right=insert(root->right,data);
    return root;
}

Node* searchRecursive(Node* root,int key)
{
    if(root==NULL||root->data==key)
        return root;
    if(key<root->data)
        return searchRecursive(root->left,key);
    else
        return searchRecursive(root->right,key);
}

Node* searchIterative(Node* root,int key)
{
    while(root!=NULL)
    {
        if(root->data==key)
            return root;
        else if(key<root->data)
            root=root->left;
        else
            root=root->right;
    }
    return NULL;
}

int main()
{
    Node* root=NULL;
    root=insert(root,10);
    insert(root,5);
    insert(root,15);
    insert(root,2);
    insert(root,7);
    Node* res=searchRecursive(root,7);
    if(res)
        cout<<"Found Recursive\n";
    else
        cout<<"Not Found Recursive\n";
    res=searchIterative(root,15);
    if(res)
        cout<<"Found Iterative";
    else
        cout<<"Not Found Iterative";
    return 0;
}
