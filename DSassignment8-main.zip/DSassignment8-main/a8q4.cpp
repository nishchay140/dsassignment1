#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* left;
    Node* right;
};

Node* createNode(int data)
{
    Node* newNode=new Node;
    newNode->data=data;
    newNode->left=NULL;
    newNode->right=NULL;
    return newNode;
}

bool isBSTUtil(Node* root,int min,int max)
{
    if(root==NULL)
        return true;
    if(root->data<=min||root->data>=max)
        return false;
    return isBSTUtil(root->left,min,root->data)&&isBSTUtil(root->right,root->data,max);
}

bool isBST(Node* root)
{
    return isBSTUtil(root,-1000000,1000000);
}

int main()
{
    Node* root=createNode(10);
    root->left=createNode(5);
    root->right=createNode(15);
    root->left->left=createNode(2);
    root->left->right=createNode(7);
    if(isBST(root))
        cout<<"BST";
    else
        cout<<"Not BST";
    return 0;
}
