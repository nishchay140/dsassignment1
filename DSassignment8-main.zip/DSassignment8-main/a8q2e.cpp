#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* left;
    Node* right;
};

Node* createNode(int data)
{
    Node* newNode=new Node;
    newNode->data=data;
    newNode->left=NULL;
    newNode->right=NULL;
    return newNode;
}

Node* insert(Node* root,int data)
{
    if(root==NULL)
        return createNode(data);
    if(data<root->data)
        root->left=insert(root->left,data);
    else if(data>root->data)
        root->right=insert(root->right,data);
    return root;
}

Node* findMax(Node* node)
{
    while(node&&node->right!=NULL)
        node=node->right;
    return node;
}

Node* inorderPredecessor(Node* root,Node* x)
{
    if(x->left!=NULL)
        return findMax(x->left);
    Node* pred=NULL;
    while(root!=NULL)
    {
        if(x->data>root->data)
        {
            pred=root;
            root=root->right;
        }
        else if(x->data<root->data)
            root=root->left;
        else
            break;
    }
    return pred;
}

int main()
{
    Node* root=NULL;
    root=insert(root,20);
    insert(root,8);
    insert(root,22);
    insert(root,4);
    insert(root,12);
    insert(root,10);
    insert(root,14);
    Node* temp=root->left->right;
    Node* pred=inorderPredecessor(root,temp);
    cout<<"Inorder Predecessor: "<<pred->data;
    return 0;
}
